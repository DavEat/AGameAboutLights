﻿using UnityEngine;

public class AG_MirrorChoc : MonoBehaviour {

    public void DestroyChock()
    {
        Destroy(gameObject);
    }
}
