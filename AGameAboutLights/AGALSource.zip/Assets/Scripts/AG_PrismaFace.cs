﻿using UnityEngine;

public class AG_PrismaFace : AG_ElementType
{
    public Transform face1, face2;
}
