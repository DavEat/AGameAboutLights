﻿using UnityEngine;

public class AG_Color
{
    public static Color[] colorList = new Color[] { Color.red, Color.green, Color.blue };
}
